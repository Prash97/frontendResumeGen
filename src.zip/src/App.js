import React from 'react';
import './App.css';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom'

import AddUserComponent from "./component/user/AddUserComponent";

import LogInComponent from './component/user/LogInComponent';
import ResumeDetails from './component/user/ResumeDetails';
function App() {
  return (
      <div className="container">
          <Router>
              <div className="col-md-6">
                  <h1 className="text-center" style={style}>React User Application</h1>
                  <Switch>
                      <Route path="/" exact component={LogInComponent} />
                      <Route path="/create-user" component={AddUserComponent} />
                      <Route path="/resume-details" component={ResumeDetails} />
                  </Switch>
              </div>
          </Router>
      </div>
  );
}

const style = {
    color: 'red',
    margin: '10px'
}

export default App;
