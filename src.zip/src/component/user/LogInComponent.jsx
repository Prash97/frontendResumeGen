import React, { Component } from 'react'
import ApiService from "../../service/ApiService";


class LogInComponent extends Component {
    constructor(props) {
        super(props)
        this.state = {
            users: [],
            message: null,
            id: '',
            firstName: '',
            lastName: '',
            emailId: '',
            contactNo: '',
            password: '',
            userName: '',
            
        }
        this.validateUser = this.validateUser.bind(this);
       
    }
   
    validateUser = (e) => {
        e.preventDefault();
            if(this.state.userName !== "" && this.state.password !== ""){
                        ApiService.fetchUsers()
                        .then((res) => {
                            this.setState({users: res.data})
                            console.log(this.state.users);
                            this.state.users.forEach(
                                (user)  =>{
                                    if(user.userName === this.state.userName && user.password === this.state.password) {
                                        console.log("found")
                                        user !== null && this.setState({message : 'User Login successfully.'});
                                        user !== null && window.localStorage.setItem("U_NAME",user.userName);
                                        user !== null && window.localStorage.setItem("F_NAME", user.firstName);
                                        user !== null && window.localStorage.setItem("L_NAME", user.lastName);
                                        user !== null && window.localStorage.setItem("EMAIL", user.emailId);
                                        user !== null && window.localStorage.setItem("CONTACTNO", user.contactNo);
                                        user !== null && window.localStorage.setItem("PASSWORD", user.password);
                                        user !== null && JSON.stringify(window.localStorage.setItem("U_ID", user.id));
                                        this.props.history.push('/resume-details');
                                    }
                                })
                        });
                    this.setState({message : 'Invalid Credentials'})
            }else{
                this.setState({message : 'All fields are compulsory'})
            }
    }

    onChange = (e) =>
    this.setState({ [e.target.name]: e.target.value });

     render() {
        return(
            <div>
              
                <h2 className="text-center">Login</h2>
                <form>
                    {this.state.message && 
                     <div className = "errormsg">
                      {this.state.message}
                         
                     </div>
                    }

                    <div className="form-group">
                        <label>UserName:</label>
                        <input placeholder="Username" name="userName" className="form-control" value={this.state.userName} onChange={this.onChange} required/>
                    </div>

                    <div className="form-group">
                        <label>Password:</label>
                        <input placeholder="Password" name="password" className="form-control" value={this.state.password} onChange={this.onChange} required/>
                    </div>
                <button className="btn btn-success " onClick={this.validateUser}>Login</button>
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                <a href = "create-user" className="float-end btn btn-warning">Register User</a>
                </form>
    </div>
        );
    }

}

export default LogInComponent;